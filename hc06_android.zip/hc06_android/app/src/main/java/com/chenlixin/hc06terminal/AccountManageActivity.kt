package com.chenlixin.hc06terminal

import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.chenlixin.hc06terminal.databinding.ActivityAccountManageBinding

class AccountManageActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAccountManageBinding
    private val maxAccounts = 10

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAccountManageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backButton.setOnClickListener { finish() }
        binding.addAccountButton.setOnClickListener { addAccount() }

        refreshList()
    }

    private fun addAccount() {
        val username = binding.newUsernameInput.text?.toString().orEmpty().trim()
        val password = binding.newPasswordInput.text?.toString().orEmpty().trim()
        if (username.isBlank() || password.isBlank()) {
            Toast.makeText(this, "账号或密码不能为空", Toast.LENGTH_SHORT).show()
            return
        }
        val accounts = AccountStorage.load(this)
        if (accounts.size >= maxAccounts) {
            Toast.makeText(this, "最多只能添加${maxAccounts}个账号", Toast.LENGTH_SHORT).show()
            return
        }
        if (accounts.any { it.username == username }) {
            Toast.makeText(this, "账号已存在", Toast.LENGTH_SHORT).show()
            return
        }
        accounts.add(Account(username, password))
        AccountStorage.save(this, accounts)
        binding.newUsernameInput.setText("")
        binding.newPasswordInput.setText("")
        refreshList()
    }

    private fun refreshList() {
        val accounts = AccountStorage.load(this)
        binding.accountCountText.text = "已添加: ${accounts.size}/$maxAccounts"
        binding.accountListContainer.removeAllViews()
        if (accounts.isEmpty()) {
            val empty = TextView(this).apply {
                text = "暂无账号"
                setPadding(dp(4), dp(4), dp(4), dp(4))
            }
            binding.accountListContainer.addView(empty)
            return
        }
        accounts.forEachIndexed { index, account ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                setPadding(0, dp(6), 0, dp(6))
                gravity = Gravity.CENTER_VERTICAL
            }
            val label = TextView(this).apply {
                text = "${index + 1}. ${account.username} / ${account.password}"
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            val deleteButton = Button(this).apply {
                text = "删除"
                setOnClickListener {
                    val list = AccountStorage.load(this@AccountManageActivity)
                    val updated = list.filterNot { it.username == account.username }
                    AccountStorage.save(this@AccountManageActivity, updated)
                    refreshList()
                }
            }
            row.addView(label)
            row.addView(deleteButton)
            binding.accountListContainer.addView(row)
        }
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }
}
