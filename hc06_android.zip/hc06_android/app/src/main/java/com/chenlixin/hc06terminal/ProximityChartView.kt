package com.chenlixin.hc06terminal

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.text.TextPaint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class ProximityChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val data = mutableListOf<ProximityEvent>()
    private var lastPlotRect: RectF? = null
    private var lastVisibleItems: List<ProximityEvent> = emptyList()
    private var lastVisiblePoints: List<PointF> = emptyList()
    private var selectedEvent: ProximityEvent? = null
    private var onPointSelected: ((ProximityEvent) -> Unit)? = null

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1f)
        color = 0x1A000000.toInt()
    }

    private val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1.25f)
        color = 0x33000000.toInt()
    }

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2.5f)
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = 0xFF2563EB.toInt()
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF2563EB.toInt()
    }

    private val pointStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1.5f)
        color = 0xFFFFFFFF.toInt()
    }

    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x99000000.toInt()
        textSize = dp(11f)
    }

    private val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xCC000000.toInt()
        textSize = dp(12f)
    }

    private val tooltipTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF111827.toInt()
        textSize = dp(12f)
    }

    private val tooltipBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xEEFFFFFF.toInt()
    }

    private val tooltipStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1f)
        color = 0x22000000.toInt()
    }

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun setData(items: List<ProximityEvent>) {
        data.clear()
        data.addAll(items)
        invalidate()
    }

    fun addPoint(event: ProximityEvent) {
        data.add(event)
        invalidate()
    }

    fun setOnPointSelectedListener(listener: ((ProximityEvent) -> Unit)?) {
        onPointSelected = listener
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked != MotionEvent.ACTION_UP) return true
        val plot = lastPlotRect ?: return true
        if (!plot.contains(event.x, event.y)) {
            selectedEvent = null
            invalidate()
            return true
        }
        val points = lastVisiblePoints
        val items = lastVisibleItems
        if (points.isEmpty() || items.isEmpty() || points.size != items.size) return true

        val threshold = dp(18f)
        var bestIdx = -1
        var bestDist2 = threshold * threshold
        for (i in points.indices) {
            val dx = points[i].x - event.x
            val dy = points[i].y - event.y
            val d2 = dx * dx + dy * dy
            if (d2 <= bestDist2) {
                bestDist2 = d2
                bestIdx = i
            }
        }
        if (bestIdx >= 0) {
            val picked = items[bestIdx]
            selectedEvent = picked
            invalidate()
            onPointSelected?.invoke(picked)
        } else {
            selectedEvent = null
            invalidate()
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val paddingLeft = dp(46f)
        val paddingRight = dp(14f)
        val paddingTop = dp(32f)
        val paddingBottom = dp(28f)

        val title = "靠近距离曲线"
        val titleBaseline = dp(20f)
        canvas.drawText(title, paddingLeft, titleBaseline, titlePaint)

        val plot = RectF(
            paddingLeft,
            paddingTop,
            w - paddingRight,
            h - paddingBottom
        )
        if (plot.width() <= 0f || plot.height() <= 0f) return
        lastPlotRect = RectF(plot)

        bgPaint.shader = LinearGradient(
            0f, plot.top, 0f, plot.bottom,
            0x0F2563EB, 0x00FFFFFF,
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(plot, dp(12f), dp(12f), bgPaint)

        canvas.drawLine(plot.left, plot.bottom, plot.right, plot.bottom, axisPaint)
        canvas.drawLine(plot.left, plot.top, plot.left, plot.bottom, axisPaint)

        val items = data.takeLast(120)
        lastVisibleItems = items
        if (items.isEmpty()) {
            val msg = "暂无数据"
            val x = plot.centerX() - titlePaint.measureText(msg) / 2f
            val y = plot.centerY()
            canvas.drawText(msg, x, y, titlePaint)
            lastVisiblePoints = emptyList()
            return
        }

        val minT = items.minOf { it.timestampMillis }
        val maxT = items.maxOf { it.timestampMillis }
        val minY = items.minOf { it.distanceCm }
        val maxY = items.maxOf { it.distanceCm }

        val yPad = max(5f, (maxY - minY) * 0.15f)
        val yMin = max(0f, minY - yPad)
        val yMax = maxY + yPad

        val timeSpan = max(1L, maxT - minT)

        val gridLines = 4
        for (i in 0..gridLines) {
            val t = i / gridLines.toFloat()
            val y = plot.bottom - t * plot.height()
            canvas.drawLine(plot.left, y, plot.right, y, gridPaint)
            val value = yMin + t * (yMax - yMin)
            val label = "${value.toInt()}cm"
            val lx = dp(6f)
            val ly = y + dp(4f)
            canvas.drawText(label, lx, ly, textPaint)
        }

        val xLabelLeft = timeFormat.format(Date(minT))
        val xLabelRight = timeFormat.format(Date(maxT))
        canvas.drawText(xLabelLeft, plot.left, h - dp(10f), textPaint)
        val rightWidth = textPaint.measureText(xLabelRight)
        canvas.drawText(xLabelRight, plot.right - rightWidth, h - dp(10f), textPaint)

        val path = Path()
        val fillPath = Path()
        val points = ArrayList<PointF>(items.size)

        items.forEachIndexed { idx, e ->
            val x = plot.left + ((e.timestampMillis - minT).toFloat() / timeSpan) * plot.width()
            val yy = (e.distanceCm - yMin) / max(0.0001f, (yMax - yMin))
            val y = plot.bottom - yy * plot.height()
            points.add(PointF(x, y))
            if (idx == 0) {
                path.moveTo(x, y)
                fillPath.moveTo(x, plot.bottom)
                fillPath.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }
        lastVisiblePoints = points

        val last = items.last()
        val lastX = plot.left + ((last.timestampMillis - minT).toFloat() / timeSpan) * plot.width()
        fillPath.lineTo(lastX, plot.bottom)
        fillPath.close()

        fillPaint.shader = LinearGradient(
            0f, plot.top, 0f, plot.bottom,
            0x332563EB, 0x002563EB,
            Shader.TileMode.CLAMP
        )
        canvas.drawPath(fillPath, fillPaint)
        canvas.drawPath(path, linePaint)

        val radius = dp(4f)
        val start = max(0, points.size - 40)
        for (i in start until points.size) {
            val p = points[i]
            canvas.drawCircle(p.x, p.y, radius, pointPaint)
            canvas.drawCircle(p.x, p.y, radius, pointStrokePaint)
        }

        val sel = selectedEvent
        if (sel != null) {
            val idx = items.indexOfFirst {
                it.timestampMillis == sel.timestampMillis && it.distanceCm == sel.distanceCm
            }
            if (idx >= 0 && idx < points.size) {
                val p = points[idx]
                canvas.drawCircle(p.x, p.y, dp(6f), pointPaint)
                canvas.drawCircle(p.x, p.y, dp(6f), pointStrokePaint)

                val label = "${timeFormat.format(Date(sel.timestampMillis))}  ${trimFloat(sel.distanceCm)}cm"
                val paddingX = dp(8f)
                val paddingY = dp(6f)
                val textW = tooltipTextPaint.measureText(label)
                val textH = tooltipTextPaint.fontMetrics.run { bottom - top }
                val boxW = textW + paddingX * 2
                val boxH = textH + paddingY * 2

                var left = p.x + dp(10f)
                var top = p.y - boxH - dp(10f)
                if (left + boxW > plot.right) left = p.x - boxW - dp(10f)
                if (top < plot.top) top = p.y + dp(10f)
                left = max(plot.left, min(left, plot.right - boxW))
                top = max(plot.top, min(top, plot.bottom - boxH))

                val rect = RectF(left, top, left + boxW, top + boxH)
                canvas.drawRoundRect(rect, dp(10f), dp(10f), tooltipBgPaint)
                canvas.drawRoundRect(rect, dp(10f), dp(10f), tooltipStrokePaint)

                val textX = rect.left + paddingX
                val textY = rect.top + paddingY - tooltipTextPaint.fontMetrics.top
                canvas.drawText(label, textX, textY, tooltipTextPaint)
            }
        }
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density

    private fun trimFloat(value: Float): String {
        val rounded = (value * 10f).toInt() / 10f
        val s = rounded.toString()
        return if (s.endsWith(".0")) s.dropLast(2) else s
    }
}
