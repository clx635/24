package com.chenlixin.hc06terminal

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.chenlixin.hc06terminal.databinding.ActivityDataProcessBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DataProcessActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDataProcessBinding
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private val listener: (ProximityEvent) -> Unit = {
        binding.chartView.addPoint(it)
        binding.countText.text = "总有 ${ProximityDataStore.size()} 次检测到有人靠近"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDataProcessBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backButton.setOnClickListener { finish() }
        binding.clearButton.setOnClickListener {
            ProximityDataStore.clear()
            binding.chartView.setData(emptyList())
            binding.countText.text = "总有 0 次检测到有人靠近"
        }

        binding.chartView.setData(ProximityDataStore.snapshot())
        binding.countText.text = "总有 ${ProximityDataStore.size()} 次检测到有人靠近"
        binding.chartView.setOnPointSelectedListener {
            val time = timeFormat.format(Date(it.timestampMillis))
            val distance = it.distanceCm
            Toast.makeText(this, "时间: $time  距离: ${distance}cm", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onStart() {
        super.onStart()
        ProximityDataStore.register(listener)
    }

    override fun onStop() {
        ProximityDataStore.unregister(listener)
        super.onStop()
    }
}
