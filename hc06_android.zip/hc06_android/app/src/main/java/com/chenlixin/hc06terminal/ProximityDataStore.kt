package com.chenlixin.hc06terminal

import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList

data class ProximityEvent(val timestampMillis: Long, val distanceCm: Float)

object ProximityDataStore {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val items = mutableListOf<ProximityEvent>()
    private val listeners = CopyOnWriteArrayList<(ProximityEvent) -> Unit>()

    @Synchronized
    fun snapshot(): List<ProximityEvent> = items.toList()

    @Synchronized
    fun size(): Int = items.size

    fun add(event: ProximityEvent) {
        val shouldNotify: Boolean
        synchronized(this) {
            items.add(event)
            shouldNotify = listeners.isNotEmpty()
        }
        if (!shouldNotify) return
        mainHandler.post {
            listeners.forEach { it(event) }
        }
    }

    fun register(listener: (ProximityEvent) -> Unit) {
        listeners.add(listener)
    }

    fun unregister(listener: (ProximityEvent) -> Unit) {
        listeners.remove(listener)
    }

    @Synchronized
    fun clear() {
        items.clear()
    }
}
